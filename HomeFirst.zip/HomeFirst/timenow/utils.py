from datetime import datetime, date

now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
today = date.today()
menu = [{'title': "Таблица умножения", 'url_name': 'multytable'},
        {'title': "День программиста", 'url_name': 'day_it'}]

table = []
for i in range(1, 11):
    for j in range(1, 11):
        table.append(f'{i}*{j} = {i*j}')


def year_it_calc():
    year = today.year
    v_year_four = year % 4
    v_year_handr = year % 100
    if year % 400 == 0 or (v_year_four == 0 and v_year_handr != 0):
        return True
    else:
        return False


def calc_day_it():
    if year_it_calc():
        return f'День программиста в этом году 12 сентября.'
    else:
        return f'День программиста в этом году 13 сентября.'
