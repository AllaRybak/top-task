from datetime import date

today = date.today()
menu = [{'title': "Таблица умножения", 'url_name': 'multytable'},
        {'title': "День программиста", 'url_name': 'day_it'}]


table = [f'{a}*{b} = {a * b}' for a in range(1, 11) for b in range(1, 11)]


def calc_day_it():
    year = today.year
    v_year_four = year % 4
    v_year_handr = year % 100
    if year % 400 == 0 or (v_year_four == 0 and v_year_handr != 0):
        return f'День программиста в этом году 12 сентября.'
    else:
        return f'День программиста в этом году 13 сентября.'
