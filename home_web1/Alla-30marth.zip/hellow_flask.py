from flask import Flask, render_template, request
import utils

app = Flask(__name__)


@app.route('/')
def hello_flask():
    return f'Hello from Flask! Продолжить - /entry'


# @app.route('/get_data') # можно несколько декраторов (ссылки)
# @app.route('/data', methods=['POST'])
# def data_flask():
#     data_txt1 = request.form['data_txt']
#     title1 = 'Go text'
#     resault = utils.count_punct(data_txt1)
#     return render_template('result.html', resault=resault, the_title=title1)


# @app.route('/data1', methods=['POST'])
# def data_flask1():
#     resault1 = '123321'
#     return render_template('result.html', resault=resault1, the_title='title1')

# @app.route('/get_data_json')
# def data_json():
#     return utils.data_get_json()


# @app.route('/random')
# def random():
#     import random
#     num = str(random.randint(-100, 100))
#     titlw = 'Счастливое число'
#     return render_template('rand.html', the_title=titlw, the_num=num)
# ______________________________________домашнее задание
@app.route('/data', methods=['POST'])
def data_flask():
    title1 = 'Результат проверки.'
    num_user = request.form['number_input']
    resault = utils.lucky_num(num_user)
    return render_template('results.html', resault=resault, the_title=title1)


@app.route('/entry')
def entry():
    return render_template('entry.html', the_title='Домашнее задание от 30.03.2023')


if __name__ == "__main__":
    app.run(debug=True)
