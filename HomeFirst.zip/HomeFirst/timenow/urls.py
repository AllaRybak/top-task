from django.urls import path
from .views import *

urlpatterns = [
    path('', index, name='home'),
    path('multytable/', multytable, name='multytable'),
    path('day_it/', day_it, name='day_it'),
]