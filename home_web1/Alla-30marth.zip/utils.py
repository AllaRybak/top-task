import string
import json

# def count_punct(text: str) -> str:
#     buf = list(filter(lambda x: x in string.punctuation, text))
#     return str(len(buf))
#
#
# def data_get_json() -> str:
#     data_dict = {'auth': 'Marina',
#                  'data': '27-03-2023',
#                  'app': 'Hello flask'}
#     return json.dumps(data_dict)

# ________ домашее задание


def lucky_num(num: str) -> str:
    half = len(num) // 2
    sum1 = sum([int(i) for i in num[:half]])
    sum2 = sum([int(i) for i in num[-half:]])
    if sum1 == sum2:
        return f'Число {num} счастливое.'
    else:
        return f'Число {num} не счастливое.'
