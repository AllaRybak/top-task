from django.shortcuts import render
from .utils import *
# Create your views here.


def index(request):
    context = {
        'title': 'Текущее время',
        'now_time': now,
        'menu': menu
    }
    return render(request, 'index.html', context=context)


def multytable(request):
    context = {
        'title': 'Таблица умножения',
        'table': table
    }
    return render(request, 'multytable.html', context=context)


def day_it(request):
    context = {
        'title': 'День программиста',
        'day': calc_day_it()
    }
    return render(request, 'day_it.html', context=context)
